require(["jquery"], function($) {
        jQuery(document).ready(function(){
       // alert('test');
       var url = jQuery(location).attr('href');
       // console.log(loc);
        if(url ==='http://www.schmuck-box.ch/en/checkout/#payment') {

        jQuery('img[src="https://checkout.postfinance.ch/en-US/s/10480/resource/web/image/payment/online-banking/postfinance-e-finance.svg?strategy=snapshot&snapshot=16914"]').attr('src','https://checkout.postfinance.ch/en-US/s/10480/resource/web/image/payment/method/twint.svg?strategy=snapshot&snapshot=16914');
        }
        }); 
});