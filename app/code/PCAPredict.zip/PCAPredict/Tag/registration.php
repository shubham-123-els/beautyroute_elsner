<?php
/**
 * Copyright © 2017 PCA Predict. All rights reserved.
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'PCAPredict_Tag',
    __DIR__
);