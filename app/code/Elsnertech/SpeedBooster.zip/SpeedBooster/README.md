# SpeedBooster

Before intall extension you need to add below dependancy to your magento.
	
composer require rosell-dk/webp-convert

Speed up website
Speed Booster