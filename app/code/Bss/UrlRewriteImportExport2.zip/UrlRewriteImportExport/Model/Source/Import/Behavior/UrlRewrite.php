<?php
namespace Bss\UrlRewriteImportExport\Model\Source\Import\Behavior;

use Magento\ImportExport\Model\Import;

class UrlRewrite extends \Magento\ImportExport\Model\Source\Import\Behavior\Basic
{
    /**
     * @inheritdoc
     */
    public function getCode()
    {
        return 'bss_rewrite';
    }

    /**
     * @return array
     */
    public function getEnableBehaviorFields()
    {
        return [
            "behavior" => [],
            Import::FIELD_NAME_VALIDATION_STRATEGY => [],
            Import::FIELD_NAME_ALLOWED_ERROR_COUNT => [],
            Import::FIELD_EMPTY_ATTRIBUTE_VALUE_CONSTANT => []
        ];
    }
}
