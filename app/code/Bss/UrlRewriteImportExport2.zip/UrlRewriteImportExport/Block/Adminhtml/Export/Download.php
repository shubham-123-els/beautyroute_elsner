<?php

namespace Bss\UrlRewriteImportExport\Block\Adminhtml\Export;

use \Magento\Framework\View\Element\Template;
use \Magento\Framework\View\Element\Template\Context;

class Download extends Template
{

    protected $storeManager;

    /**
     * Download constructor.
     * @param Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->storeManager = $storeManager;
        parent::__construct($context);
    }

    /**
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getBaseUrl()
    {
        return $this->storeManager->getStore()->getBaseUrl();
    }

    /**
     * @return mixed
     */
    public function getDirectoryData()
    {
        return $this->getDirectory();
    }

    /**
     * @return mixed
     */
    public function getFileNameData()
    {
        return $this->getFileName();
    }
}
