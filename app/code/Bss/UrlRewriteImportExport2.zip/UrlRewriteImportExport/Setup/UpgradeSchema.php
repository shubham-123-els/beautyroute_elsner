<?php
namespace Bss\UrlRewriteImportExport\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class UpgradeSchema
 *
 * @package Bss\UrlRewriteImportExport\Setup
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * Add new row to table url_rewrite
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $installer = $setup;
        $installer->startSetup();
        if (version_compare($context->getVersion(), '1.0.8', '<')) {
            $installer->getConnection()->addColumn(
                $installer->getTable('url_rewrite'),
                'ignore_nonexist_target_path_error',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    'length' => 10,
                    'nullable' => true,
                    'comment' => 'Ignore Nonexist target path error'
                ]
            );
        }
        $installer->endSetup();
    }
}
