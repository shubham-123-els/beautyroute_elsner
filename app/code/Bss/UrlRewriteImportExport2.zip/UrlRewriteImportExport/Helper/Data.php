<?php
namespace Bss\UrlRewriteImportExport\Helper;

use Magento\Framework\App\Helper\Context;

/**
 * Class Data
 *
 * @package Bss\UrlRewriteImportExport\Helper
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * Data constructor.
     * @param Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->storeManager = $storeManager;
        parent::__construct($context);
    }

    /**
     * Get all store ids of website
     *
     * @return array
     */
    public function getAllStoreIds()
    {
        $storeIds = [];
        foreach ($this->storeManager->getStores() as $store) {
            $storeIds[] = $store->getStoreId();
        }
        return $storeIds;
    }
}
