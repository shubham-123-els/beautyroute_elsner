var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/view/minicart': {
                'Codilar_HelloWorld/js/checkout/view/minicart': true
            }
        }
    }
    
};